import{_ as m}from"./index.vue_vue_type_script_setup_true_lang-CcyOOkWf.js";import"./index-Co0mQimf.js";export{m as default};
